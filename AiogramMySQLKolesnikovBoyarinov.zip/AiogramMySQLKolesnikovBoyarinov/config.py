# API Token
API_TOKEN = '5595500871:AAFJqccOSaG3fcRP5-Ew5xb1gLMrWcjNMec'

# Admin ID
admin_id = 1303173596

# Database connection settings
dbHost = 'sql.freedb.tech'
dbUser = 'freedb_KolesnikovBoyarinov'
dbPassword = 'b!PkUz!%u5?M975'
dbName = 'freedb_KolesoBoyara'